// Do your task here:




// Do not modify code below

const icon = document.querySelector('.weather-icon');
const type = document.querySelector('.weather-type');
const weatherLocation = document.querySelector('.location');
const temperature = document.querySelector('.temperature span');

if (forecast) {
    icon.src = 'images/' + forecast.icon;
    type.textContent = forecast.type;
    weatherLocation.textContent = forecast.location;
    temperature.textContent = forecast.temperature;
}